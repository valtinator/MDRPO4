-- Remnant - Cinder Fall
-- Card ID: 5501551
-- MDPro4 / YGOPro-style Lua script. Test in MDPro4 1.0.2.

local s,id=GetID()
local CINDER_ID=5501550
local TOKEN_ID=5501552
local REMNANT_SET=0x1550

function s.initial_effect(c)
    c:EnableReviveLimit()
    -- Synchro materials: 1 Tuner + 1+ non-Tuner "Remnant" monsters.
    -- A DARK Remnant can also serve as the Tuner for this Synchro Summon.
    aux.AddSynchroProcedure(c,s.tunerfilter,1,1,s.nontunerfilter,1,99)

    -- Once per turn (Quick Effect): negate the target, halve its current ATK,
    -- then Special Summon an Essence Token with the target's original stats/effects.
    local e1=Effect.CreateEffect(c)
    e1:SetDescription(aux.Stringid(id,0))
    e1:SetCategory(CATEGORY_DISABLE+CATEGORY_ATKCHANGE+CATEGORY_SPECIAL_SUMMON)
    e1:SetType(EFFECT_TYPE_QUICK_O)
    e1:SetCode(EVENT_FREE_CHAIN)
    e1:SetProperty(EFFECT_FLAG_CARD_TARGET)
    e1:SetRange(LOCATION_MZONE)
    e1:SetCountLimit(1)
    e1:SetTarget(s.tktg)
    e1:SetOperation(s.tkop)
    c:RegisterEffect(e1)

    -- While an Essence Token is on the field, this card is unaffected by other cards' effects.
    local e2=Effect.CreateEffect(c)
    e2:SetType(EFFECT_TYPE_SINGLE)
    e2:SetCode(EFFECT_IMMUNE_EFFECT)
    e2:SetCondition(s.immcon)
    e2:SetValue(s.immval)
    c:RegisterEffect(e2)

    -- If this card leaves the field, Special Summon Remnant - Cinder from Deck/GY/face-up banishment.
    local e3=Effect.CreateEffect(c)
    e3:SetDescription(aux.Stringid(id,1))
    e3:SetCategory(CATEGORY_SPECIAL_SUMMON)
    e3:SetType(EFFECT_TYPE_SINGLE+EFFECT_TYPE_TRIGGER_O)
    e3:SetProperty(EFFECT_FLAG_DELAY)
    e3:SetCode(EVENT_LEAVE_FIELD)
    e3:SetTarget(s.cindertg)
    e3:SetOperation(s.cinderop)
    c:RegisterEffect(e3)
end

function s.istremnant(c)
    return c:IsSetCard(REMNANT_SET) or c:IsCode(CINDER_ID)
end

function s.tunerfilter(c)
    return c:IsType(TYPE_TUNER) or (c:IsAttribute(ATTRIBUTE_DARK) and s.istremnant(c))
end

function s.nontunerfilter(c)
    return not c:IsType(TYPE_TUNER) and s.istremnant(c)
end

function s.tkfilter(c,e)
    return c:IsFaceup() and c:IsType(TYPE_MONSTER) and c~=e:GetHandler()
end

function s.tktg(e,tp,eg,ep,ev,re,r,rp,chk,chkc)
    if chkc then return chkc:IsLocation(LOCATION_MZONE) and s.tkfilter(chkc,e) end
    if chk==0 then
        return Duel.IsExistingTarget(s.tkfilter,tp,LOCATION_MZONE,LOCATION_MZONE,1,nil,e)
    end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_FACEUP)
    Duel.SelectTarget(tp,s.tkfilter,tp,LOCATION_MZONE,LOCATION_MZONE,1,1,nil,e)
    Duel.SetOperationInfo(0,CATEGORY_DISABLE,nil,1,0,0)
    Duel.SetOperationInfo(0,CATEGORY_ATKCHANGE,nil,1,0,0)
    Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_MZONE)
end

function s.tkop(e,tp,eg,ep,ev,re,r,rp)
    local c=e:GetHandler()
    local tc=Duel.GetFirstTarget()
    if not tc or not tc:IsRelateToEffect(e) or not tc:IsFaceup() or not tc:IsLocation(LOCATION_MZONE) then return end

    -- Snapshot the target's printed/base stats and original code before applying negation.
    local baseatk=tc:GetBaseAttack()
    local basedef=tc:GetBaseDefense()
    local originalcode=tc:GetOriginalCode()
    local currentatk=tc:GetAttack()

    Duel.NegateRelatedChain(tc,RESET_TURN_SET)
    local e1=Effect.CreateEffect(c)
    e1:SetType(EFFECT_TYPE_SINGLE)
    e1:SetCode(EFFECT_DISABLE)
    e1:SetReset(RESET_EVENT+RESETS_STANDARD)
    tc:RegisterEffect(e1)
    local e2=Effect.CreateEffect(c)
    e2:SetType(EFFECT_TYPE_SINGLE)
    e2:SetCode(EFFECT_DISABLE_EFFECT)
    e2:SetReset(RESET_EVENT+RESETS_STANDARD)
    tc:RegisterEffect(e2)

    local e3=Effect.CreateEffect(c)
    e3:SetType(EFFECT_TYPE_SINGLE)
    e3:SetCode(EFFECT_SET_ATTACK_FINAL)
    e3:SetValue(math.floor(currentatk/2))
    e3:SetReset(RESET_EVENT+RESETS_STANDARD)
    tc:RegisterEffect(e3)

    -- The token is optional and is summoned after the previous part resolves ("then").
    if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
    if not Duel.SelectYesNo(tp,aux.Stringid(id,2)) then return end
    Duel.BreakEffect()
    local token=Duel.CreateToken(tp,TOKEN_ID)
    if not token then return end
    if not Duel.SpecialSummonStep(token,0,tp,tp,false,false,POS_FACEUP) then return end

    local a=Effect.CreateEffect(c)
    a:SetType(EFFECT_TYPE_SINGLE)
    a:SetCode(EFFECT_SET_ATTACK)
    a:SetValue(baseatk)
    a:SetReset(RESET_EVENT+RESETS_STANDARD)
    token:RegisterEffect(a)
    local d=Effect.CreateEffect(c)
    d:SetType(EFFECT_TYPE_SINGLE)
    d:SetCode(EFFECT_SET_DEFENSE)
    d:SetValue(basedef)
    d:SetReset(RESET_EVENT+RESETS_STANDARD)
    token:RegisterEffect(d)

    -- Copy the target's printed effects before the summon event is completed,
    -- so copied on-Special-Summon triggers can see the summon event.
    if originalcode and originalcode>0 and tc:GetOriginalType()&TYPE_EFFECT==TYPE_EFFECT then
        token:CopyEffect(originalcode,RESET_EVENT+RESETS_STANDARD,1)
    end
    Duel.SpecialSummonComplete()
end

function s.immcon(e)
    return Duel.IsExistingMatchingCard(Card.IsCode,e:GetHandlerPlayer(),LOCATION_MZONE,LOCATION_MZONE,1,nil,TOKEN_ID)
end

function s.immval(e,re)
    return re:GetOwner()~=e:GetHandler()
end

function s.cindertg(e,tp,eg,ep,ev,re,r,rp,chk)
    if chk==0 then
        return Duel.GetLocationCount(tp,LOCATION_MZONE)>0 and Duel.IsExistingMatchingCard(function(c) return c:IsCode(CINDER_ID) and (not c:IsLocation(LOCATION_REMOVED) or c:IsFaceup()) and c:IsCanBeSpecialSummoned(nil,0,tp,false,false) end,tp,LOCATION_DECK+LOCATION_GRAVE+LOCATION_REMOVED,0,1,nil)
    end
    Duel.SetOperationInfo(0,CATEGORY_SPECIAL_SUMMON,nil,1,tp,LOCATION_DECK+LOCATION_GRAVE+LOCATION_REMOVED)
end

function s.cinderop(e,tp,eg,ep,ev,re,r,rp)
    if Duel.GetLocationCount(tp,LOCATION_MZONE)<=0 then return end
    local g=Duel.GetMatchingGroup(function(c) return c:IsCode(CINDER_ID) and (not c:IsLocation(LOCATION_REMOVED) or c:IsFaceup()) and c:IsCanBeSpecialSummoned(nil,0,tp,false,false) end,tp,LOCATION_DECK+LOCATION_GRAVE+LOCATION_REMOVED,0,nil)
    if #g==0 then return end
    Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
    local sc=g:Select(tp,1,1,nil):GetFirst()
    if sc then Duel.SpecialSummon(sc,0,tp,tp,false,false,POS_FACEUP) end
end
